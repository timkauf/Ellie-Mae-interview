# Pre-interview Code Project
## by Tim Kaufman

### Instructions To Run Project

1. Make sure these are installed:
	- [node.js](http://nodejs.org/)
	- [gulp](http://gulpjs.com/)
	- [ruby](https://www.ruby-lang.org/en/documentation/installation/)

2. CD to the folder `cd elliemae-interview`
3. Run `npm-install` to load dependencies
4. Run the command `gulp`
5. After building, it will run a web server and launch in browser